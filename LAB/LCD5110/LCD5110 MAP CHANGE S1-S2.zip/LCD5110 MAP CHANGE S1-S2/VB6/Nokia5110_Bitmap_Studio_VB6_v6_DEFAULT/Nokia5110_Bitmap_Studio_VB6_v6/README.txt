Nokia 5110 Bitmap Studio v5 - layout reorganizat
===================================================

Aceasta versiune pastreaza functionalitatea v4. Modificarile sunt
strict la aranjarea obiectelor: antet clar, doua zone de lucru
aliniate, optiuni de conversie sub imagini, editare si export
grupate separat, cu spatii mai mici intre controale.

Deschide Nokia5110_Bitmap_Studio.vbp in Visual Basic 6.
Nu sunt necesare controale OCX externe. Modulul modWheel.bas
ramane indispensabil pentru rotita mouse-ului.

Nokia 5110 Bitmap Studio v4 - Lock & Paint (VB6)

Instalare: extrage toate fisierele intr-un folder simplu, de exemplu C:\VB6\Nokia5110. Deschide Nokia5110_Bitmap_Studio.vbp in Visual Basic 6.

STANGA (fotografia originala)
- Muta mouse-ul: cadrul galben urmareste cursorul.
- CLICK STANGA: fixeaza cadrul (verde), inca un click il elibereaza (galben).
- ROTITA: micsoreaza/mareste cadrul, inclusiv cand este fix.
- CLICK DREAPTA + TRAGERE: deseneaza puncte negre peste fotografia din stanga.
- SHIFT + CLICK DREAPTA + TRAGERE: sterge punctele desenate pe stanga.
- Desenul din stanga ramane ancorat in fotografia originala, nu in ecranul LCD.

DREAPTA (bitmap LCD 84x48)
- CLICK STANGA + TRAGERE: pixel negru.
- CLICK DREAPTA + TRAGERE: sterge pixel (alb).
- ROTITA: modifica pragul alb/negru.
- Dithering se activeaza din checkbox.
- "Sterge retusurile" elimina modificarile pe ambele imagini.

EXPORT: Export HEX produce 504 octeti in format pagina PCD8544. Butonul Sursa Verilog creeaza un modul LCD5110 cu bitmap inclus integral; nu necesita fisier HEX separat.

IMPORTANT VB6: modulul modWheel.bas foloseste subclassing Windows pentru WM_MOUSEWHEEL. Inchide fereastra normal, nu apasa Stop/End din IDE cat timp aplicatia este pornita.

Versiunea este actualizata structural, dar nu a fost compilata cu Visual Basic 6 sub Windows.

VERSIUNEA 6 - EXEMPLU IMPLICIT
------------------------------------
La pornire, incarca automat exemplu_implicit.png in ambele zone.
Pastreaza acest fisier in acelasi director cu .vbp sau .exe.
Fotografia poate fi inlocuita apoi prin butonul Deschide.
